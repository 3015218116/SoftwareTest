package Tp;
import static org.junit.Assert.assertEquals;

import org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
public class Tes {

	private static Tpt p ;
	
	@Before
	public void SetUp() {
		p = new Tpt();		
	}
	
	@Test
	public void TestTraigle() {
		assertEquals(true,p.isEquilateral(5, 5, 5));
		assertEquals(false,p.isEquilateral(-1, -1, -1));
		assertEquals(true,p.isosceles(5, 5, 4));
		assertEquals(false,p.isEquilateral(-1, -1, -2));
		assertEquals(true,p.isTraigle(3, 4, 5));
		assertEquals(false,p.isTraigle(-3,-4,-5));
		assertEquals(false,p.isTraigle(100,2, 5));
		assertEquals(true,p.scalene(4, 5, 6));
		assertEquals(false,p.scalene(-5, 5, 6));
		assertEquals(false,p.scalene(3,3 ,3));
		assertEquals(false,p.scalene(4,5,5));
		assertEquals(false,p.scalene(100, 2 , 5));
		
	}
	
}
