package Tp;

public class Tpt {

	public boolean isTraigle(double a , double b ,double c)
	{
		if(a<0||b<0||c<0)
			return false ;
		if(a+b>c&&a+c>b&&b+c>a)
		{
			return true ;
		}
		return false ;
	}
	public boolean isEquilateral(double a ,double b ,double c)
	{
		if(isTraigle(a,b,c))
		{
			if(a==b&&a==c)
			{
				return true ;
			}
		}
		return false ;
	}
	public boolean isosceles(double a,double b, double c)
	{
		if(isTraigle(a,b,c))
		{
			if((a==b&&a!=c)||(a==c&&a!=b)||(b==c&&b!=a))
			{
				return true ;
			}
		}
		return false ;
	}
	
	public boolean scalene(double a ,double b ,double c)
	{
		
		if(isTraigle(a,b,c))
		{
			if(!isEquilateral(a,b,c)&&!isosceles(a,b,c))
			{
				return true ;
			}
		}
		return false ;
	}
}
